import snowflake.connector
import pandas as pd
from snowflake.sqlalchemy import URL
from sqlalchemy import create_engine
import boto3

# We can connect Snowflake using the Python connector.
url = URL(
    user='xxx',
    password='xxx',
    account='xxx',
    warehouse='COMPUTE_WH',
    database='GPIPIS_DB',
    schema='PUBLIC',
    role = 'SYSADMIN'
)
engine = create_engine(url)
 
 
connection = engine.connect()


# Copy the data from S3 Bucket to Snowflake 
truncate_query = """
truncate TEST_TABLE
"""
 
copy_query = """
copy into TEST_TABLE
from @my_s3_test_snowflake_stage/exports/
file_format= (type = csv field_delimiter=',' skip_header=1)
"""
 
 
trunc_query = connection.execute(truncate_query)
 
cp_query = connection.execute(copy_query)
