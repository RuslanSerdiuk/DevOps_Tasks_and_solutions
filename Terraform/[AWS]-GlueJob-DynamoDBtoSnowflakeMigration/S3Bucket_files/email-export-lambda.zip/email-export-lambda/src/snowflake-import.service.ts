import 'source-map-support/register';
import {SnowflakeProvider, SnowflakeSdkConnection} from "@src/snowflake.provider";

export class SnowflakeImportService {

  constructor(private readonly snowflakeProvider: SnowflakeProvider) {
  }

  public async importSettingsToSnowflake(): Promise<void> {
    const connection = await this.snowflakeProvider.getConnection();

    const today = new Date().toISOString().slice(0, 10); //2023-01-30 format

    console.log(`Importing data from email-settings-export/${today}`)

    await this.executeQuery(`TRUNCATE email_settings`, connection);

    await this.executeQuery(`copy into email_settings
        from @warehouse.notifications.s3_pns_bucket_dynamo_stage/email-settings-export/${today}
        file_format = (type = csv field_delimiter = ',' skip_header = 1, FIELD_OPTIONALLY_ENCLOSED_BY='"');`,
      connection);


    return Promise.resolve();
  }

  private executeQuery<T = any>(sql: string, connection: SnowflakeSdkConnection): Promise<T> {
    return new Promise<any>((resolve, reject) => {
      connection.execute({
        sqlText: sql,
        complete: (err, _stmt, rows) => {
          if (err) {
            return reject(err);
          }

          resolve(rows);
        },
      });
    });
  }
}
