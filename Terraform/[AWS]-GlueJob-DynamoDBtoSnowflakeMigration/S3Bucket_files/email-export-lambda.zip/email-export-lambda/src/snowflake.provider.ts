import { EventEmitter } from 'events';

import * as snowflake from 'snowflake-sdk';

export interface SnowflakeStatement extends EventEmitter {
  getNumRows(): number;
  streamRows(params: { start: number; end: number }): SnowflakeStatement;
}

export interface SnowflakeExecuteParams {
  sqlText: string;
  streamResult?: boolean;
  complete(err: Error, stmt: SnowflakeStatement, rows: any): void;
}

export interface SnowflakeSdkConnection {
  getId(): string;
  isUp(): boolean;
  execute(params: SnowflakeExecuteParams): void;
  destroy(onDestroy: (err: Error, conn: SnowflakeSdkConnection) => void): void;
}

export interface SnowflakeConnection {
  account: string;
  username: string;
  password: string;
  database: string;
  warehouse: string;
  schema?: string;
  clientSessionKeepAlive: boolean;
}


export class SnowflakeProvider {
  private connection: SnowflakeSdkConnection;

  private static createConnection(connection: SnowflakeConnection): Promise<SnowflakeSdkConnection> {
    return new Promise((resolve, reject) => {
      snowflake.createConnection(connection).connect((err: Error, conn: SnowflakeSdkConnection) => {
        if (err) {
          return reject(err);
        } else {
          resolve(conn);
        }
      });
    });
  }

  constructor(private readonly connectionOptions: SnowflakeConnection) {}

  public async getConnection(): Promise<SnowflakeSdkConnection> {
    if (!this.connection) {
      const conn = await this.connect(this.connectionOptions);

      if (conn) {
        this.connection = conn;
      }
    }

    return this.connection;
  }

  private connect(configuration: SnowflakeConnection): Promise<SnowflakeSdkConnection | void> {
    return SnowflakeProvider.createConnection(configuration)
      .then(newConnection => {
        console.log('[SnowFlake Provider] Connected to Snowflake', {
          isUp: newConnection.isUp(),
          connectionId: newConnection.getId(),
        });

        return newConnection;
      })
      .catch(err => {
        console.error('[SnowFlake Provider] Unable connect to Snowflake: ' + err.message);
      });
  }
}
