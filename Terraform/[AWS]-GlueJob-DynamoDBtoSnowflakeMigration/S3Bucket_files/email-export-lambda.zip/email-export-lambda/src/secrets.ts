import {SnowflakeConnection} from "@src/snowflake.provider";
import AWS from 'aws-sdk';

async function getSecret(secretName): Promise<string> {
    const config = { region: process.env.AWS_REGION };
    const secretsManager = new AWS.SecretsManager(config);

    const secretValue = await secretsManager.getSecretValue({ SecretId: secretName }).promise();
    return secretValue.SecretString;
}

export async function getSnowflakeConnectionOptions(): Promise<SnowflakeConnection> {
    const secret = JSON.parse(await getSecret('s3-to-snowflake-credentials-migration-pd'));

    return {
        account: secret.SNOWFLAKE_NOTIFICATIONS_ACCOUNT,
        username: secret.SNOWFLAKE_NOTIFICATIONS_USER,
        password: secret.SNOWFLAKE_NOTIFICATIONS_PASSWORD,
        database: secret.SNOWFLAKE_NOTIFICATIONS_DB,
        warehouse: secret.SNOWFLAKE_NOTIFICATIONS_WAREHOUSE,
        schema: secret.SNOWFLAKE_NOTIFICATIONS_SCHEMA,
        clientSessionKeepAlive: false,
    };
}