import {SnowflakeProvider} from "@src/snowflake.provider";
import {getSnowflakeConnectionOptions} from "@src/secrets";
import {SnowflakeImportService} from "@src/snowflake-import.service";

let snowflakeProvider;

export const lambdaHandler = async (): Promise<void> => {
    console.log(`Starting lambda execution`);

    if(!snowflakeProvider){
        const connectionOptions = await  getSnowflakeConnectionOptions();
        snowflakeProvider = new SnowflakeProvider(connectionOptions)
    }

    await new SnowflakeImportService(snowflakeProvider).importSettingsToSnowflake();

    return;
};